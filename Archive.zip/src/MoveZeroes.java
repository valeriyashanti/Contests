public class MoveZeroes {
    public static void main(String[] args) {
        int [] n = new int[]{1, 0,0, 3, 4};
//        moveZeroes(n);
        System.out.println(n);
    }


//    public static void moveZeroes(int[] nums) {
//
//
//        for (int i= 1; i < nums.length; i++){
//            if (nums[i] != 0 && nums[i - 1] == 0)
//        }
//    }
}