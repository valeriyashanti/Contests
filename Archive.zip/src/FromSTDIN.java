public class FromSTDIN {
    public static void main(String[] args) {
        return ;
    }
}
