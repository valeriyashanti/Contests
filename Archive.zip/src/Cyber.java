public class Cyber {

    public static void main(String[] args) {

        new Matrix().calculate();
    }
}